a = 5 + input() +-6 + input()
print a
