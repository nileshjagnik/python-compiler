#COMMENTS HOW ARE THESE HANDLED???

tmp0 = input()
tmp1 = - tmp0
tmp2 = tmp1 + 2
print tmp2
