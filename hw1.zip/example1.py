print - input() + 2 
