x = input()
input()
print input()
print x

