x = input()
print -x + 3