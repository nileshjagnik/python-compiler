x = [1,2]
y = x[0]
print y
