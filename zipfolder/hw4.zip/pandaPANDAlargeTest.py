a = 1
b = 1+a
c = input() + b
d = 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10
e = d + input()
f = 1
input() + input() + a
g = input()
h = -1
i = 10 + e + f + g
print a + b
j = input() + 7 + input()
k = j + a
print k
w = a + b + h + -input()
y = w + 7
z = input() + y
print z