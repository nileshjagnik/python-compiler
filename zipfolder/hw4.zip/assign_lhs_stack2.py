x = 1 + input()
y = x + x
z = y + y
f = x + y + z
print z
