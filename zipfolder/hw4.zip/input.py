input() + input()
print input()