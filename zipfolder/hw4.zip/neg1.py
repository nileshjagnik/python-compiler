x = 2
print -(1 + x)
