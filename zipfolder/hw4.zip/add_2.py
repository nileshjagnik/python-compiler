x = input()
y = input()
z = x + y
print z
