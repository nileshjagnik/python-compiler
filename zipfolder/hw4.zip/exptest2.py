x = [1,2]
y = [4,5]
z = x or y
