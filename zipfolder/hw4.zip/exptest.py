x = [1,2,6]
y = []
z = [6,7] + [8]
z = x[1] if not ((input() == 2) or 3) else ((y or x) and z)
