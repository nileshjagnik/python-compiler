if x==1:
	y=1
elif x==2:
	y=2
else:
	y=3
