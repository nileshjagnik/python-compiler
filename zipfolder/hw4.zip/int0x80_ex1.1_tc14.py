x=3
print x
