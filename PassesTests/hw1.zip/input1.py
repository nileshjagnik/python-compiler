input()
print input()
