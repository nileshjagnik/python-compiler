input() + input()
print input()
